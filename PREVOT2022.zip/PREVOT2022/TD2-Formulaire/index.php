

 <?php
if (isset($_POST["bouton"]))
{
        $email = $_POST['email'];
        $objet = $_POST['objet'];
        $message = $_POST['message'];

        echo "email : $email <br> objet : $objet <br> message :$message<br>";
        if (mail('martin.prevot75@gmail.com',$objet,$message))
        {
            echo"<br><br> Votre email a bien été envoyé. ";
        }
                else  
            {
                    echo "<br><br> Erreur envoie email!!";
             }
}

    else 
    {
            echo "erreur";
		
    }
$to = 'it@7sisters.in';
    $email_from = "info@7sisters.in";

    $full_name = 'Suraj Hazarika';
    $from_mail = $full_name.'<'.$email_from.'>';



   
    
    
    $from = $from_mail;

    $headers = "" .
               "Reply-To:" . $from . "\r\n" .
               "X-Mailer: PHP/" . phpversion();
    $headers .= 'MIME-Version: 1.0' . "\r\n";
    $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";        
    
 ?>


