 <?php
if (isset($_POST["name"]))
{
        $nom = $_POST['name'];
        $email = $_POST['email'];
        $tel = $_POST['phone'];
        $message = $_POST['message'];
        $envoie = "nom : $nom , tel : $tel , message : $message";
        $test ="Email venant de Portfolio";

        echo "email : $email <br>tek : $tel <br> nom : $nom <br> message :$message<br>";
        if (mail('martin.prevot75@gmail.com',$test,$envoie))
        {
            echo"<br><br> Votre email a bien été envoyé. ";
        }
                else  
            {
                    echo "<br><br> Erreur envoie email!!";
             }
}

    else 
    {
            echo "erreur";
		
    }

?>
