<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <link href="style1.css" media="all" rel="stylesheet" type="text/css"/>
        <title>SioReport</title>
    </head>
     <body>
<form class="login" method="POST" action="connexion.php">
				<div class="login__field">
					<i class="login__icon fas fa-user"></i>
					<input type="text" class="login__input" placeholder="login" name="login">
				</div>
				<div class="login__field">
					<i class="login__icon fas fa-lock"></i>
					<input type="password" class="login__input" placeholder="Mot de passe" name="mdp">
				</div>
					<span class="button__text"><input  class="button login__submit" type="submit" name="envoi" value="OK"></span>
			</form>			
