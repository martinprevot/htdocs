<?php
$serveurBDD="localhost";
$userBDD="root";
$mdpBDD="";
$nomBDD="td8_bloc3";
?>
