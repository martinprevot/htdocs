<?php

include '_conf.php';
if (isset($_POST['envoi']))
{
   
    $login = $_POST['login'];
    $mdp = $_POST['mdp'];
    echo "$login + $mdp<br>";

 try 
{


   $pdo = new PDO('mysql:host=localhost;dbname=td8_bloc3', 'root', '');


    $stmt=$pdo->prepare("Select * from acheteur WHERE email = ? AND motdepasse=?");
    $stmt->execute([$login, $mdp]);
    //$user = $stmt->fetch();
    $ligne=$stmt->fetch();
if (isset($ligne["id"]))
{
    echo "Connexion OK";
    $id=$ligne["id"];

    //on prépare la requête
    $stmt = $pdo->prepare('SELECT * from voir where idAcheteur= :id');
    //on l'éxecute avec le paramètres
    $stmt->execute(["id"=>$id]);

    echo "<br>Voici vos notes:";
    //tant que j'ai des lignes je stock ma ligne courante dans $ligne
    while($ligne = $stmt->fetch())
    {

        echo "<br>$ligne[note]";

    }
}
else
{
    echo "Echec connexion";
}











}




     
    catch (PDOException $e)
    {
     echo $e->getMessage();
     }

}

     /*$trouve=0;
     while($donnees = mysqli_fetch_assoc($user))
      {
   
        $trouve=1;
        $type=$donnees['id'];
        $login=$donnees['email'];
        $prenom = $donnees ['prenom'];
        $nom = $donnees ['nom'];
        echo "bienvenue $prenom";
      }

    if($trouve==0)
    {
        echo "erreur de connexion";
    }
}*/

?>
