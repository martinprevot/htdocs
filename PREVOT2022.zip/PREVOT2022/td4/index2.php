<head> <link rel="stylesheet" href="style.css"></head>
<div class="wrapper fadeInDown">
  <div id="formContent"> 
<?php
if (empty($_POST['login']) || empty($_POST['motdepasse']))
{
    echo "<br><strong class='active'> Champs de connexion pas entierrement remplis </strong>";
}
else
{   
    $login=$_POST['login'];
    $motdepasse=$_POST['motdepasse'];
    $mdp2 = md5($motdepasse);
    $trouve =0;
    include '_conf.php';
    if ($bdd = mysqli_connect($serveurBDD,$userBDD, $mdpBDD,$nomBDD))
    {
        $requete="SELECT * from ADHERENT WHERE login= '$login' and password='$mdp2';";
        $resultat = mysqli_query($bdd, $requete);
	    while($donnees = mysqli_fetch_assoc($resultat))
	    {
            $trouve =1;
	    	$var1= $donnees['nom'];
	    	$var2= $donnees['prenom'];
	    	$var3= $donnees['email'];
	    	$var4= $donnees['dateNaissance'];
	    	$var5= $donnees['Sexe'];
	    	$var6= $donnees['Annee_BAC'];
            if ($var5==1){
                $var5 ="Homme";
            }
            else
            {
                $var5="Femme";
            }
	    } 
      if ($trouve ==1)
        {
            echo "<strong class='active'> nom :  $var1<br> prenom :  $var2<br>  email :  $var3<br> Date de naissance :  $var4<br>  Sexe :  $var5<br> Année du Bac :  $var6</strong>";
        } 
            else 
            {
                echo "<br><strong class='active'>Login ou mot de passe incorrect</strong>";
            }
    }
    else {
        echo "<br><strong class='active'>Erreur connexion bdd</strong>";
        }
}
?> 
  <div id="formFooter">
            <a class="underlineHover" href="index.php">Retourner a la page de connexion</a>
  </div>
