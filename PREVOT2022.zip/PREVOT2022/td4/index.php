<head> <link rel="stylesheet" href="style.css"></head>
<div class="wrapper fadeInDown">
  <div id="formContent">
    <h2 class="active"> Connexion </h2>
    <h2 class="inactive underlineHover"><a href="inscription.php">Inscription </a></h2>
    <FORM Method="POST" Action="index2.php">      
      <input type="text" id="login" class="fadeIn second" name="login" placeholder="login">
      <input type="password" id="password" class="fadeIn third" name="motdepasse" placeholder="mot de passe">
      <input  type="submit" class="fadeIn fourth" value="Continue">
    </form>
