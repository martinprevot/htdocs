<?php
$serveurBDD="db5007058039.hosting-data.io";
$userBDD="dbu2671317";
$mdpBDD="bts2022td5";
$nomBDD="dbs5826068";
?>


