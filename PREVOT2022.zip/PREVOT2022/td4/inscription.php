<head> <link rel="stylesheet" href="style.css"></head>
<div class="wrapper fadeInDown">
  <div id="formContent">
    <h2 class="inactive underlineHover"><a href="index.php">Connexion </a></h2>
    <h2  class="active">Inscription </h2>
<FORM Method="POST" Action="inscription2.php">
      <input type="text" id="login" class="fadeIn second" name="login" placeholder="Login">
      <input type="password" id="password" class="fadeIn third" name="motdepasse" placeholder="Mot de passe">
      <input type="password" id="password2" class="fadeIn third" name="motdepasse2" placeholder="Repeter mot de passe">
      <input type="text" id="nom" class="fadeIn second" name="nom" placeholder="Nom">
      <input type="text" id="prenom" class="fadeIn third" name="prenom" placeholder="Prénom">
      <input type="text" id="email" class="fadeIn second" name="email" placeholder="Email"><br>
         <strong>         Date de Naissance    : <input type="date" id="date" class="fadeIn third" name="date" placeholder="Date de naissance"><br>
Sexe : <br>Homme    <input class="fadeIn second" type="radio" id="sexe" name="sexe" value="1">   Femme    <input class="fadeIn second" type="radio" id="sexe" name="sexe" value="0"><br>
Année du bac : 
<select name="bac" id="bac">
    <option ><?php
                    $bac=date("Y");
                    for ($i = 1980;$i <=$bac-6; $i++){
                        echo "<option>$i</option>";
                    }
                    ?></option>
</select>
</strong> 
<br><br>
      <input href ="inscription2.php"type="submit" class="fadeIn fourth" value="S'inscrire">
</form>
