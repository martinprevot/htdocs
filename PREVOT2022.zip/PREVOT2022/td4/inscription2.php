<head> <link rel="stylesheet" href="style.css"></head>
<?php
$motdepasse=$_POST['motdepasse'];
$motdepasse2=$_POST['motdepasse2'];
if ($motdepasse !=$motdepasse2){
    $test="ERREUR : Les mots de passes ne sont pas les memes";
  }
else{
if (empty($_POST['login']) || empty($_POST['motdepasse']) || empty($_POST['motdepasse2']) || empty($_POST['nom']) || empty($_POST['prenom']) || empty($_POST['email'])
 || empty($_POST['date']) ||  empty($_POST['bac']))
{
    $test="ERREUR : tous les champs n'ont pas ete renseignés.";
}
else
{
    if(isset($_POST['sexe']))
    {
$login=$_POST['login'];
$motdepasse=$_POST['motdepasse'];
$nom=$_POST['nom'];
$prenom=$_POST['prenom'];
$email=$_POST['email'];
$date=$_POST['date'];
$sexe=$_POST['sexe'];
$bac=$_POST['bac']; 
include '_conf.php';
if ($bdd = mysqli_connect($serveurBDD,$userBDD,$mdpBDD,$nomBDD))
{
$mdp=  md5($motdepasse);
$requete="INSERT INTO ADHERENT Values ('','$nom','$prenom','$email','$login','$mdp','$date','$sexe','$bac');";
$resultat = mysqli_query($bdd, $requete);
mysqli_close($bdd);
$test ="Inscription réussis ! ";
}
else 
{
    $test="Erreur connexion BDD";
}
}
 else{
        $test="ERREUR : tous les champs n'ont pas ete renseignés.";
     }
}
}
?>
<div class="wrapper fadeInDown">
  <div id="formContent">
  <body>
  <h2 class="active"><?php echo $test; ?></h2></body>
  <div id="formFooter">
            <a class="underlineHover" href="index.php">Retourner a la page de connexion</a>
        </div>
  </div>
</div>

