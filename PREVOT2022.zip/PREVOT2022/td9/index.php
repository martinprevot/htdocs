<form method="post" action="connexion.php">
login : <input type="text" name="email"><br>
mdp : <input type="password" name="mdp"><br>
<input type="submit" name="sub" value="OK">
</form>


