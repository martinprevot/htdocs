 <?php    

 function getPosts()
{
$posts = [[1, "Martin","05/05/2020", "description 1"],
[2, "Jibril","06/05/2020", "description 2"],
[3, "Nessim","07/05/2020", "description de Nessim"],
[4, "Alexander","06/05/2020", "description d'Alexander"],
[5, "Sirine","06/05/2020", "description de Sirine"],];	
		return $posts;
 }	

$tableau_1= getPosts();


foreach ($tableau_1 as $valeur) 
{
echo 
"<table border=1>

        <td>$valeur[0]</td>      
  <td>$valeur[1]</td>
<td>$valeur[2]</td>
<td>$valeur[3]</td>

</table>";
}
//récupérer la liste des postes grâce à la fonction puis afficher la sous forme de tableau

		?>
