<?php
$serveurBDD="localhost";
$userBDD="root";
$mdpBDD="";
$nomBDD="PROJET_PREVOT";
?>
