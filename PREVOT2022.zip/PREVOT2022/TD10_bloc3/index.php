<?php
echo"L'algorithme de hashage utilisé pour : '541616566e62564b788910f190cb70e6' est md5 et en version clair est 'supermanX'";
echo "<br>";
echo"L'algorithme de hashage utilisé pour : '8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918' est SHA256 et en version clair est 'admin'  ";
echo "<br>";
echo "<br>";
$string = "Vive#Les#S1aux";
$salt = "duSel";




echo 'MD5:          ',crypt($string, '$1$duSel$');

echo "<br>";echo "<br>";

echo 'SHA-256:      ',crypt($string ,'$5$rounds=5000$duSel$');


echo "<br>";echo "<br>";

echo 'SHA-512:      ', crypt($string , '$6$rounds=5000$duSel$');

echo "<br>";echo "<br>";

echo 'SHA-256 avec salt duSelFin:      ',crypt($string ,'$5$rounds=5000$duSelFin$');
echo "<br>";echo "<br>";
echo 'SHA-256 avec salt duGrosSel:      ',crypt($string ,'$5$rounds=5000$duGrosSel$');
echo "<br>";echo "<br>";

echo'Bcrypt :      ',  password_hash($string, PASSWORD_BCRYPT);

echo "<br>";echo "<br>";
$t1 = microtime();
echo'Bcrypt :      ',  password_hash($string, PASSWORD_BCRYPT);
echo "<br>";
$temps = (float) microtime () - (float) $t1;
echo "duree exécution = $temps ";




	
echo "<br>";echo "<br>";
$options = [
    'cost' => 5,
];
$t1 = microtime();
echo'Bcrypt :      ',  password_hash($string, PASSWORD_BCRYPT,$options);
echo "<br>";
$temps = (float) microtime () - (float) $t1;
echo "duree exécution en x5 = $temps ";


	
echo "<br>";echo "<br>";
$options = [
    'cost' => 15,
];
$t1 = microtime();
echo'Bcrypt :      ',  password_hash($string, PASSWORD_BCRYPT,$options);
echo "<br>";
$temps = (float) microtime () - (float) $t1;
echo "duree exécution en x15 = $temps ";
echo "<br>";echo "<br>";



echo "Les caractéristique de cette empreinte sont quelle est crypté en SHA512";
echo "<br>";echo "<br>";
$hash = '$2y$12$SuP21Kvq9xb2JXW7oSxOLudahWZdHVRvBSl1xzYPRhKurxiQTxjGW';

if (password_verify('M0t2Pass', $hash)) {
    echo 'Password is valid!';
} else {
    echo 'Invalid password.';
}







?>
